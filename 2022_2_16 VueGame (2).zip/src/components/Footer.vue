<template>
  <div class="mt-1 bg-secondary" id="footertoobar">
    <div class="container">
      <div class="row">
        <div class="d-flex  justify-content-between">
            <button type="button" class="btn btn-info">Game</button>
            <button type="button" class="btn btn-info">Bet</button>
            <button type="button" class="btn btn-info">Stastics</button>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
    name: 'footer',
    data() {
      return {
        
      }
    },
    mounted() {
      
    },
    methods: {
      
    },
}
</script>
<style scoped>

</style>