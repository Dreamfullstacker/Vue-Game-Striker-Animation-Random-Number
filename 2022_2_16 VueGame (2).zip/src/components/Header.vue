<template>
    <div class="d-flex bg-secondary">
      <div class="p-2"><button type="button" class="btn btn-info">H</button></div>
      <div class="p-2"><button type="button" class="btn btn-info">S</button></div>
      <div class="p-1 bg-info rounded-3 my-3"><span  class="badge">999.9FUN</span><button type="button" class="btn btn-success btn-sm">+</button></div>
      <div class="ml-auto p-2"><button type="button" class="btn btn-success">U</button></div>
    </div>
</template>

<script>

  export default {
        data() {
            return {
            }
        }
    }
</script>

<style>

</style>
